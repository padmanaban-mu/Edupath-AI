const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const JWT_SECRET = 'your_super_secret_key';

mongoose.connect('mongodb://127.0.0.1:27017/edupath_db');

// Updated Schema to include Roadmap state
const User = mongoose.model('User', new mongoose.Schema({
    fullName: { type: String, required: true },
    username: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    hasGeneratedRoadmap: { type: Boolean, default: false },
    roadmapData: { type: Object, default: null } 
}));

app.post('/register', async (req, res) => {
    try {
        const user = new User(req.body);
        await user.save();
        res.status(201).send({ message: "Account Created!" });
    } catch (err) {
        res.status(400).send({ error: "Email already exists" });
    }
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email, password });
    if (user) {
        const token = jwt.sign({ userId: user._id }, JWT_SECRET);
        res.send({ 
            message: "Success", 
            token: token, 
            username: user.username 
        });
    } else {
        res.status(401).send({ error: "Invalid Credentials" });
    }
});

// GET Roadmap Data
app.get("/get-roadmap", async (req, res) => {
    try {
        const token = req.headers['authorization'].split(' ')[1];
        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await User.findById(decoded.userId);
        
        res.send({
            hasGeneratedRoadmap: user.hasGeneratedRoadmap,
            roadmapData: user.roadmapData
        });
    } catch (err) {
        res.status(401).send({ error: "Unauthorized" });
    }
});

// SAVE/UPDATE Roadmap Data
app.post("/save-roadmap", async (req, res) => {
    try {
        const token = req.headers['authorization'].split(' ')[1];
        const decoded = jwt.verify(token, JWT_SECRET);
        
        await User.findByIdAndUpdate(decoded.userId, {
            hasGeneratedRoadmap: req.body.hasGeneratedRoadmap,
            roadmapData: req.body.roadmapData
        });

        res.send({ message: "Progress Saved" });
    } catch (err) {
        res.status(500).send({ error: "Failed to save" });
    }
});

app.get("/profile", async (req, res) => {
    res.set("Cache-Control", "no-store");
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await User.findById(decoded.userId);
        if (!user) return res.status(404).send({ error: "User not found" });
        res.send({ username: user.username, fullName: user.fullName });
    } catch (err) {
        res.status(401).send({ error: "Invalid Session" });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));